<?php session_start();?>
<?php include('head.php');?>
<link rel="stylesheet" href="popup_style.css">

   <?php
  include('connect.php');
if(isset($_POST['btn_login']))
{
$unm = $_POST['email'];

$passw = $_POST['password'];

// function createSalt()
// {
//     return '2123293dsj2hu2nikhiljdsd';
// }
// $salt = createSalt();
// $pass = hash('sha256', $salt . $passw);

 $sql = "SELECT * FROM tbl_student WHERE semail='" .$unm . "' and password = '". $passw."'";
    $result = mysqli_query($conn,$sql);
    $row  = mysqli_fetch_array($result);
    
    /* $_SESSION["id"] = $row['id'];
     $_SESSION["username"] = $row['username'];*/
     
     $_SESSION["semail"] = $row['semail'];
     $_SESSION["password"] = $row['password'];
    /* $_SESSION["fname"] = $row['fname'];
     $_SESSION["lname"] = $row['lname'];
     $_SESSION["image"] = $row['image'];*/
	 
	 
     $count=mysqli_num_rows($result);
     if($count==1 && isset($_SESSION["semail"]) && isset($_SESSION["password"])) {
    {       
        ?>

         <div class="popup popup--icon -success js_success-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Success 
    </h1>
    <p>Login Successfully</p>
    <p>
    
     <?php echo "<script>setTimeout(\"location.href = 'student_panel.php';\",1500);</script>"; ?>
    </p>
  </div>
</div>
  
     <?php
    }
}
else {?>
     <div class="popup popup--icon -error js_error-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Error 
    </h1>
    <p>Invalid Email or Password</p>
    <p>
      <a href="stdlogin.php"><button class="button button--error" data-for="js_error-popup">Close</button></a>
    </p>
  </div>
</div>
       
        <?php
       
         }
    
    }
?>

    <div id="main-wrapper bg-secondary">
        <div class="unix-login">
             <?php
             $sql_login = "select * from manage_website"; 
             $result_login = $conn->query($sql_login);
             $row_login = mysqli_fetch_array($result_login);
             ?>
            <div class="container-fluid"  style="background-image: url('uploadImage/Logo/<?php echo $row_login['background_login_image'];?>');
 background-image: url('uploadImage/prashant.jpeg ">


                           
        <div id="" class="pull-left">
        <h1><a href="#intro" class="scrollto text-success">STUDENT LOGIN</a></h1>
         </div>
                                <div class=" col-sm-4 pull-right text-light"> 
                                    <div class=" col"><h2 class="menu-active pull-left"><a href="login.php">ADMIN LOGIN</a></h2></div>
                                          <div class=" col"> <h2><a href="stdlogin.php" class="pull-right">STUDENT LOGIN</a></h2></div>
                                </div>

                <div class="row justify-content-center" >
                    <div class="col-sm-8">
                                        
                        <div class="login-content card">
                            <div class="login-form">
                                <center><h4>STUDENT</h4><img src="uploadImage/stdlogo.jpg" style="width:50%;"></center><br>
                                <form method="POST">
                                    <div class="form-group">
                                        <label>Email address</label>
                                        <input type="email" name="email" class="form-control" placeholder="Email" required="">
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required="">
                                    </div>
                                    <div class="checkbox">
                                           <label class="pull-right">
                                                <a href="student_forgot_password.php">Forgotten Password?</a>
                                           </label>   
                                    </div>
                                    <button type="submit" name="btn_login" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
                                  
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
	
    
    <script src="js/lib/jquery/jquery.min.js"></script>

    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>

    <script src="js/jquery.slimscroll.js"></script>

    <script src="js/sidebarmenu.js"></script>

    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/custom.min.js"></script>

</body>

</html>