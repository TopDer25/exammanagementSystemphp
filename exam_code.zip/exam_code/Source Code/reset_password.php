<!-- reset_password.php -->
<?php
include('connect.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Validate the reset token
    $sql = "SELECT * FROM admin WHERE reset_token='$token' AND token_expiry > NOW()";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
    $count = mysqli_num_rows($result);

    if ($count == 1) {
        if (isset($_POST['submit'])) {
            $new_password = $_POST['password'];
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the admin's password and clear the token
            $sql_update = "UPDATE admin SET password='$hashed_password', reset_token=NULL, token_expiry=NULL WHERE id='{$row['id']}'";
            if (mysqli_query($conn, $sql_update)) {
                echo "Your password has been successfully reset.";
                echo "<script>setTimeout(function(){ window.location.href = 'adminlogin.php'; }, 2000);</script>";
            } else {
                echo "Failed to reset password.";
            }
        }
    } else {
        echo "Invalid or expired token.";
    }
} else {
    echo "No reset token provided.";
}
?>

<!-- HTML form to reset password -->
<form method="POST">
    <div class="form-group">
        <label>New Password</label>
        <input type="password" name="password" class="form-control" placeholder="Enter new password" required="">
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Reset Password</button>
</form>
