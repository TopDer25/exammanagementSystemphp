              
        <div class="left-sidebar">
            
            <div class="scroll-sidebar">
        
										
										
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label"><h2 class="text-dark">Home</h2></li>
                        <li> <a href="student_panel" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a></li>
                             <li><a href="std_today.php">Student's Details</a></li>
                             <li><a href="student_panel.php">Today's Exam</a></li>                                
                          </ul>
						  
						  </nav>
						  
						  </div>
						  </div>
                          