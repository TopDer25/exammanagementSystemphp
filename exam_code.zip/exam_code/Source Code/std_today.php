<?php include('head.php');?>
<?php include('header1.php');?>

  
<?php
 date_default_timezone_set('Asia/Kolkata');
 $current_date = date('Y-m-d');

 $sql_currency = "select * from manage_website"; 
             $result_currency = $conn->query($sql_currency);
             $row_currency = mysqli_fetch_array($result_currency);
?>    

             <div class="left-sidebar">
                        
                        <div class="scroll-sidebar">
                            
                            <nav class="sidebar-nav">
                                <ul id="sidebarnav">
                                    <li class="nav-devider"></li>
                                    <li class="nav-label"><h2 class="text-dark">Home</h2></li>
                                    <li> <a href="" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a></li>
                                             <li><a href="std_today.php">Student's Details</a></li>
                                            <li><a href="student_panel.php">Today's Exam</a></li>
											</ul></nav></div></div>
      
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Dashboard</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            
              <div class="container-fluid">                    
               <div class="card">

              <div class="container-fluid">                    
               <div class="card">

                                <div class="table-responsive m-t-40">
                                    <table id="<? #myTable?>" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Class</th>
                                                <th>Email</th>
                                                <th>Gender</th>
                                                <th>Birth Date</th>
                                                <th>Contact No.</th>
                                               <th>Address</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php 
                                    include 'connect.php';
                                    $sql = "SELECT * FROM `tbl_student` where semail= '".$_SESSION["semail"]."' ";
                                     $result = $conn->query($sql);
                                        $i=0;
                                   while($row = $result->fetch_assoc()) { 
                                    $sql2 = "SELECT * FROM `tbl_class` WHERE id='".$row['classname']."'";
                                     $result2=$conn->query($sql2);
                                     $row2=$result2->fetch_assoc();
                                      ?>
                                            <tr>
                                                <td><?php echo $row['sfname']; ?></td>
                                                <td><?php echo $row['slname']; ?></td>
                                                <td><?php echo $row2['classname']; ?></td>
                                                <td><?php echo $row['semail']; ?></td>
                                                <td><?php echo $row['sgender']; ?></td>
                                                <td><?php echo $row['sdob']; ?></td>
                                                <td><?php echo $row['scontact']; ?></td>
                                                <td><?php echo $row['saddress']; ?></td>
                                                
                                               
                                            </tr>
                                          <?php  $i++;} 
                                          ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
               
<?php include('footer.php');?>