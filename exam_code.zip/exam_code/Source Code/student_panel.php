<?php include('head.php');?>
<?php include('header1.php');?>

  
<?php
 date_default_timezone_set('Asia/Kolkata');
 $current_date = date('Y-m-d');

 $sql_currency = "select * from manage_website"; 
             $result_currency = $conn->query($sql_currency);
             $row_currency = mysqli_fetch_array($result_currency);
?>    

             <div class="left-sidebar">
                        
                        <div class="scroll-sidebar">
                            
                            <nav class="sidebar-nav">
                                <ul id="sidebarnav">
                                    <li class="nav-devider"></li>
                                    <li class="nav-label"><h2 class="text-dark">Home</h2></li>
                                    <li> <a href="" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a></li>
                                             <li><a href="std_today.php">Student's Details</a></li>
                                            <li><a href="student_panel.php">Today's Exam</a></li></ul></nav></div></div>
      
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Dashboard</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            
              <div class="container-fluid">                    
               <div class="card">

                            
                            <div class="card-body">
                                <div class="table-responsive m-t-40">
                                    <table id="<? #myTable?>" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Exam Name</th>
                                                <th>Exam Date</th>
                                                <th>Time</th> 
                                                <th>Class Name</th>
                                                <th>Subject Name</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php 
                                    include 'connect.php';
									
									 /* $sql = "SELECT * FROM `tbl_student` where semail= '".$_SESSION["semail"]."' ";*/
                                  
                                  $sql1 = "SELECT * FROM  exam ";
                                   $result1 = $conn->query($sql1);
                                   while($row = $result1->fetch_assoc()) {

                                    $s2 = "SELECT * FROM `tbl_class` WHERE id='".$row['class_id']."'";
                                    $sr1 = $conn->query($s2);
                                    $sres1 = mysqli_fetch_array($sr1);

									
									
                                    $s3 = "SELECT * FROM `tbl_subject` WHERE id='".$row['subject_id']."'";
                                    $sr2 = $conn->query($s3);
                                    $sres2 = mysqli_fetch_array($sr2); 
                                      ?>
                                            <tr>
                                                <td><?php echo $row['name']; ?></td>
                                                <td><?php echo $row['exam_date']; ?></td>
                                                <td><?php echo $row['start_time'].'-'.$row['end_time']; ?></td>
                                                <td><?php echo $sres1['classname']; ?></td>
                                                <td><?php echo $sres2['subjectname']; ?></td>
                                            </tr>
                                          <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> 
        </div>
            
            <?php include('footer.php');?>